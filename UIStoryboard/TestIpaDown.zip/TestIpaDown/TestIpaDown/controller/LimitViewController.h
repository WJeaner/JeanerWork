//
//  LimitViewController.h
//  TestIpaDown
//
//  Created by gaokunpeng on 15/8/2.
//  Copyright (c) 2015年 gaokunpeng. All rights reserved.
//

#import "BaseViewController.h"

@interface LimitViewController : BaseViewController

@end
