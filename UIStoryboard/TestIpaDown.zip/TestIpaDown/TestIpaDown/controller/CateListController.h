//
//  CateListController.h
//  TestIpaDown
//
//  Created by gaokunpeng on 15/8/2.
//  Copyright (c) 2015年 gaokunpeng. All rights reserved.
//

#import "BaseViewController.h"

@interface CateListController : BaseViewController

@property (nonatomic,strong)NSString *categoryStr;

@property (nonatomic,strong)NSString *cateName;

@end
