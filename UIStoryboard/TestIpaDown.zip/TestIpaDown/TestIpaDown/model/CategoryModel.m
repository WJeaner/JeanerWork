//
//  CategoryModel.m
//  TestIpaDown
//
//  Created by gaokunpeng on 15/8/2.
//  Copyright (c) 2015年 gaokunpeng. All rights reserved.
//

#import "CategoryModel.h"

@implementation CategoryModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{}

@end

@implementation CategoryType

-(void)setValue:(id)value forUndefinedKey:(NSString *)key
{}

@end
